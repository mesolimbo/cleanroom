// This file is currently empty as we're handling all the functionality in the background script
// It's included in the manifest for future extensibility if needed
console.log('Page Snapshot extension content script loaded'); 